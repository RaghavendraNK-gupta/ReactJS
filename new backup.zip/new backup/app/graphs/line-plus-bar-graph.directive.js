'use strict';

angular.module('propel-analytic-ui')
  .directive('linePlusBarGraph', function () {
    return {
      restrict: 'E',
      templateUrl: 'templates/propel-analytic-ui/graphs/line-plus-bar-graph.html',
      scope: {
        graphOptions: '=',
        commonOptions: '=',
        id: '@'
      },

      controller: 'linePlusBarGraphController',
      controllerAs: 'vm'
    };
  })
  .controller('linePlusBarGraphController', function ($scope, $stateParams, $location, $translate, dateFilter, intervals, currency2Filter, parseWeek, parseYear, parseMonth, dateFormat, AnalyticApi, GRAPH_TYPES, GRAPH_STATES, globalError) {
    var vm = this;
    vm.intervalsList = {
      'week': [$translate.instant('analytic.home.interval.week'), 6],
      'month': [$translate.instant('analytic.home.interval.month'), 1],
      'three-month': [$translate.instant('analytic.home.interval.three-month'), 3],
      'six-month': [$translate.instant('analytic.home.interval.six-month'), 6],
      'year': [$translate.instant('analytic.home.interval.year'), 12]
    };

    vm.commonOptions = $scope.commonOptions;
    vm.graphOptions = $scope.graphOptions;
    vm.getDateFormat = function (date, format) {
      var f = format ? format : 'MMM dd yyyy';
      return dateFilter(date, f);
    };

    vm.id = $scope.id;
    vm.types = GRAPH_TYPES;
    vm.states = GRAPH_STATES;
    var yAxis1Max = 0;
    var yAxis2Max = 0;
    vm.isSupportType = function () {
      if (vm.graphOptions.entityType === 'supports') {
        return true;
      }
    };

    function transformData(responseData) {
      var transform = {
        'WEEK': function (data) {
          return parseWeek.parseDataMulti(data);
        },
        'MONTH': function (data) {
          return parseMonth.parseDataMulti(data);
        },
        'YEAR': function (data) {
          return parseYear.parseDataMulti(data);
        }
      };
      return transform[responseData.granularity](responseData);

    }

    function next() {
      var query = Object.extended(vm.commonOptions).merge(vm.graphOptions);
      query = Object.reject(query, 'graphType');
      Object.merge(query, intervals.select(query.interval));
      delete query.interval;
      if ($stateParams.mock) {
        query.mock = true;
      }
      query.mock = true;
      //console.log("query",query);
      return AnalyticApi.list(query)
        .$promise
        .then(function (analyticsData) {
          //var formattedData = tranformData(analyticsData);
          vm.graphData = transformData(analyticsData);
          if (analyticsData.currency) {
            vm.currency = analyticsData.currency;
          }
          updateChart();
          console.log("graphData", vm.graphData);
        })
        .catch(function () {
          globalError.show('analytics.notFound');
          return [];
        });
    }

    vm.setState = function (state) {
      vm.graphOptions.state = state;
      next();
    };

    vm.tooltipContent = function (d) {
      //	console.log(d);
      if (d === null) {
        return '';
      }
      var date = new Date(d.series[0].data[0]);
      // var day = date.getDate();
      // var monthIndex = date.getMonth();
      // var year = date.getFullYear();
      var toDate;

      Date.prototype.addDays = function (days) {
        var d = new Date(this.valueOf());
        d.setDate(d.getDate() + days);
        return d;
      };
      var fromDate = vm.getDateFormat(date);
      if ($location.search().interval === 'week') {
        toDate = date.addDays(vm.intervalsList[$location.search().interval][1]);
      } else {
        toDate = date.setMonth(date.getMonth() + vm.intervalsList[$location.search().interval][1]);
        toDate = new Date(toDate);
        toDate.setDate(toDate.getDate() - 1);
      }
      var maxToDate = $location.search().to;
      maxToDate = new Date(maxToDate);
      toDate = (toDate > maxToDate) ? maxToDate : toDate;
      toDate = vm.getDateFormat(toDate);

      var trow = '';
      for (var i = 0; i < d.series.length; i++) {
        if (d.series[i].color) {
          var keyValue = d.series[i].value;
          if (d.series[i].key.indexOf('Cost') > -1) {
            //keyValue = '$' + d3.format(',.2f')(d.series[i].value);
            //console.log("vm.currency",vm.currency);
            keyValue = currency2Filter(d.series[i].value, vm.currency);
            trow += '<tr class="highlight"><td class="legend-color-guide"><div style="background-color: ' + d.series[i].color + '"></div></td><td class="key"> Total Cost </td><td class="value">' + keyValue + '</td></tr>';
          } else {
            var cost = currency2Filter(d.series[i].data[2], vm.currency);
            trow += '<tr class="highlight"><td class="legend-color-guide"><div style="background-color: ' + d.series[i].color + '"></div></td><td class="key">' + d.series[i].key + '</td><td class="value">' + d.series[i].value + '</td></tr>';
            trow += '<tr class="highlight"><td></td><td class="key"> Cost </td><td class="value">' + cost + '</td></tr>';
          }
        }
      }
      var html = '<table style="width:90%;" border="0"><thead><tr><td colspan="3"><strong class="x-value"><h5>' + vm.intervalsList[$location.search().interval][0] + '</h5>' + fromDate + ' - ' + toDate + '</strong></td></tr></thead><tbody>' + trow + '</tbody></table>';
      return html;
    }

    vm.options = {
      chart: {
        type: 'multiChart',
        height: 450,
        margin: {
          top: 30,
          right: 90,
          bottom: 30,
          left: 50,
        },
        color: ['turquoise', 'grey', 'silver', 'blue'],
        useInteractiveGuideline: true,
        duration: 500,
        x: function (d) {
          return d[0] || d.x
        },
        y: function (d) {
          return d[1]
        },
        xAxis: {
          tickFormat: function (d) {
            //return d3.time.format('%x')(new Date(d));
            return dateFormat.format(new Date(d), 'MMM dd ');
          }
        },
        yAxis1: {
          tickFormat: function (d) {
            if (yAxis1Max < d) {
              yAxis1Max = d;
            }
            return d3.format(',.1f')(d);
          }
        },
        yAxis2: {
          tickFormat: function (d) {
            if (yAxis2Max < d) {
              yAxis2Max = d;
            }
            return currency2Filter(d, vm.currency);
          }
        },
        interactiveLayer: {
          tooltip: {
            contentGenerator: vm.tooltipContent,
            classes: 'customizeTooltip'
          }
        },
        callback: function (chart) {
          chart.bars1.stacked(true);
          chart.bars2.stacked(true);
          vm.chart = chart;
          updateChart();
        }
      }
    };

    function updateChart() {
      if (vm.chart) {
        vm.chart.yDomain1([0, getMaxCount()]);
        vm.chart.yDomain2([0, getMaxCost()]);
        vm.chart.legend.updateState(true);
        vm.chart.update();
      }
    }

    function getMaxCost() {
      var max = 0;
      for (var i = 0; i < vm.graphData[0].values.length; i++) {
        var calcMax = 0;
        for (var j = 0; j < vm.graphData.length - 1; j++) {
          //index cost value array reads the cost data
          calcMax += vm.graphData[j].values[i][2];
        }
        if (calcMax > max) {
          max = calcMax;
        }
      }
      return max;
    }

    function getMaxCount() {
      var max = 0;
      for (var i = 0; i < vm.graphData[0].values.length; i++) {
        var calcMax = 0;
        for (var j = 0; j < vm.graphData.length - 1; j++) {
          calcMax += vm.graphData[j].values[i][1];
        }
        if (calcMax > max) {
          max = calcMax;
        }
      }
      return max;
    }

    $scope.$watch('commonOptions', function (newValue) {
      vm.commonOptions = newValue;
      next();
    }, true);
  });
