'use strict';

angular.module('propel-analytic-ui')
  .service('parseMonth', function () {

    this.parseData = function (data) {
      var areaData = [];
      var services = data.services || data.supports;
      for (var i = 0; i < services.length; i++) {
        var service = services[i];
        var serviceObj = {};
        var serviceVals = [];
        serviceObj.key = service.name;
        var modifiedDate = new Date(data.from);
        var serviceValues = service.values;
        for (var j = 0, length = serviceValues.length; j < length; j++) {
          var val = [];
          if (j === 0) {
            modifiedDate.setMonth(modifiedDate.getMonth());
          } else {
            modifiedDate.setMonth(modifiedDate.getMonth() + parseInt(data.factor));
          }
          val.push(modifiedDate.getTime());
          val.push(serviceValues[j]);
          if (data.currency) {
            val.push(data.currency);
          }
          serviceVals.push(val);
        }
        serviceObj.values = serviceVals;
        areaData.push(serviceObj);
      }
      return areaData;
    };

    this.parseDataMulti = function (data) {
      var areaData = [];
      var services = data.services || data.supports;

      var costVals = []; //new
      for (var i = 0; i < services.length; i++) {
        var service = services[i];
        var serviceObj = {};
        var serviceVals = [];
        serviceObj.key = service.name;
        var modifiedDate = new Date(data.from);
        var serviceValues = service.values;
        for (var j = 0, length = serviceValues.length; j < length; j++) {
          var val = [];
          if (j === 0) {
            modifiedDate.setMonth(modifiedDate.getMonth());
          } else {
            modifiedDate.setMonth(modifiedDate.getMonth() + parseInt(data.factor));
          }
          val.push(modifiedDate.getTime());
          val.push(serviceValues[j].count);
          val.push(serviceValues[j].cost);
          if (data.currency) {
            val.push(data.currency);
          }
          serviceVals.push(val);
          var costVal = [];
          if (i === 0) {
            costVal.push(modifiedDate.getTime());
            costVal.push(serviceValues[j].cost);
            costVals.push(costVal);
          } else {
            costVal = costVals[j];
            costVal[1] = costVal[1] + serviceValues[j].cost;
            costVals[j] = costVal;
          }
        }
        serviceObj.values = serviceVals;
        serviceObj.type = "bar";
        serviceObj.yAxis = 1;
        areaData.push(serviceObj);
      }

      var costObj = {}; //new
      costObj.key = "Cost";
      costObj.values = costVals;
      costObj.type = "line";
      costObj.yAxis = 2;
      areaData.push(costObj);
      return areaData;
    };
  });
