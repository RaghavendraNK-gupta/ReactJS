'use strict';

angular.module('propel-analytic-ui')
  .service('transformSunburstData', ['parseWeekSunburst', 'parseMonthSunburst', 'parseYearSunburst', function (parseWeekSunburst, parseMonthSunburst, parseYearSunburst) {

    this.transform = function (responseData) {
      var transformFunc = {
        'WEEK': function (data) {
          return parseWeekSunburst.parseData(data);
        },
        'MONTH': function (data) {
          return parseMonthSunburst.parseData(data);
        },
        'YEAR': function (data) {
          return parseYearSunburst.parseData(data);
        }
      };
      return transformFunc[responseData.granularity](responseData);
    };
  }]);
