'use strict';

angular.module('propel-analytic-ui')
  .service('transformData', ['parseWeek', 'parseMonth', 'parseYear', function (parseWeek, parseMonth, parseYear) {

    this.transform = function (responseData) {
      var transformFunc = {
        'WEEK': function (data) {
          return parseWeek.parseData(data);
        },
        'MONTH': function (data) {
          return parseMonth.parseData(data);
        },
        'YEAR': function (data) {
          return parseYear.parseData(data);
        }
      };
      return transformFunc[responseData.granularity](responseData);
    };
  }]);
