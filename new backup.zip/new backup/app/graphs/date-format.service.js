'use strict';

angular.module('propel-analytic-ui')
  .service('dateFormat', ['dateFilter', function (dateFilter) {
    this.format = function (date, format) {
      var f = format ? format : 'MMM dd yyyy';
      return dateFilter(date, f);
    };
  }]);
