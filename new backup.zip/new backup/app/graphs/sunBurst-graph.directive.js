'use strict';

angular.module('propel-analytic-ui')
  .directive('sunBurstGraph', function () {
    return {
      restrict: 'E',
      templateUrl: 'templates/propel-analytic-ui/graphs/sun-burst-graph.html',
      scope: {
        graphOptions: '=',
        commonOptions: '=',
        id: '@'
      },
      controller: 'sunBurstGraphController',
      controllerAs: 'vm'
    };
  })
  .controller('sunBurstGraphController', function ($scope, $stateParams, $location, $filter, $translate, intervals, AnalyticApi, GRAPH_TYPES, GRAPH_STATES, globalError, transformSunburstData) {
    var vm = this;

    vm.intervalsList = {
      'week': [$translate.instant('analytic.home.interval.week'), 6],
      'month': [$translate.instant('analytic.home.interval.month'), 1],
      'three-month': [$translate.instant('analytic.home.interval.three-month'), 3],
      'six-month': [$translate.instant('analytic.home.interval.six-month'), 6],
      'year': [$translate.instant('analytic.home.interval.year'), 12]
    };

    vm.commonOptions = $scope.commonOptions;
    vm.graphOptions = $scope.graphOptions;
    vm.getDateFormat = function (date, format) {
      var f = format ? format : 'MMM dd yyyy';
      return $filter('date')(date, f);
    };

    vm.id = $scope.id;
    vm.types = GRAPH_TYPES;
    vm.states = GRAPH_STATES;

    vm.isSupportType = function () {
      if (vm.entityType === 'supports') {
        return true;
      }
    };

    function next() {

      var query = Object.extended(vm.commonOptions).merge(vm.graphOptions);
      query = Object.reject(query, 'graphType');
      Object.merge(query, intervals.select(query.interval));
      delete query.interval;
      if ($stateParams.mock) {
        query.mock = true;
      }
      query.mock = true;

      return AnalyticApi.list(query)
        .$promise
        .then(function (analyticsData) {
          vm.graphData = transformSunburstData.transform(analyticsData);
          //vm.graphData = parseMonthSunburst.parseData(analyticsData);

        })
        .catch(function () {
          globalError.show('analytics.notFound');
          return [];
        });
    }
    vm.graphOptions.state = 'ALL';
    vm.setState = function (state) {
      vm.graphOptions.state = state;
      next();
    };

    vm.setType = function (type) {
      vm.graphOptions.type = type;
      next();
    };

    vm.options = {
      chart: {
        type: 'sunburstChart',
        height: 450,
        color: ['Turquoise', 'LightGrey', 'LightestGrey'],
        duration: 250,
        useInteractiveGuideline: true,
        callback: function (chart) {
          vm.chart = chart;
        }
      }
    };
    $scope.$watch('commonOptions', function (newValue) {
      vm.commonOptions = newValue;
      next();
    }, true);
  });
