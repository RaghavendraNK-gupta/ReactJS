'use strict';

angular.module('propel-analytic-ui')
  .constant('GRAPH_TYPES', ['COST', 'COUNT'])
  .constant('GRAPH_STATES', ['OPEN', 'FULFILLED']);
