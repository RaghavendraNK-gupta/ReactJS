'use strict';

angular.module('propel-analytic-ui')
  .service('parseWeekSunburst', function () {
    this.parseData = function (responseData) {
      var areaData = [];

      var areaDataChildren = {};

      areaDataChildren.name = responseData.type;
      areaDataChildren.children = [];
      areaData.push(areaDataChildren);

      for (var index in responseData.services) {

        var ch1 = {};
        var open = {};
        open.size = 0;

        var fulfilled = {};
        fulfilled.size = 0;


        var parent = responseData.services[index];
        ch1.name = parent.name;

        ch1.size = 0;
        ch1.children = [];
        ch1.children.push({
          name: 'open',
          size: 0,
          children: []
        });
        ch1.children.push({
          name: 'fulfilled',
          size: 0,
          children: []
        });

        for (var x = 0; x < parent.values.length; x++) {

          ch1.size += parent.values[x]['open'] + parent.values[x]['fulfilled'];
          if (Object.keys(parent.values[x]).indexOf('open') != -1) {
            open.name = responseData.type + ' of open for ' + responseData.factor + responseData.granularity + s;
            open.size = parent.values[x]['open'];
            ch1.children[0].size += open.size;
            ch1.children[0].children.push(open);
          }

          if (Object.keys(parent.values[x]).indexOf('fulfilled') != -1) {
            var s = '';
            if (responseData.factor > 1) {
              s = 's';
            }
            fulfilled.name = responseData.type + ' of fulfilled for ' +
              responseData.factor + '' + 'Week';
            fulfilled.size = parent.values[x]['fulfilled'];
            ch1.children[1].size += fulfilled.size;
            ch1.children[1].children.push(fulfilled);
          }

        }

        areaDataChildren.children.push(ch1)
      }


      return areaData;

    };

  });
