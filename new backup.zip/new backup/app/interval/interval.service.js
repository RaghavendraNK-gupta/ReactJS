'use strict';

angular.module('propel-analytic-ui')
  .service('intervals', function () {

    var intervals = [{
      id: 'week',
      query: {
        granularity: 'WEEK',
        factor: 1
      },
      days: 7,
      disabled: false
    }, {
      id: 'month',
      query: {
        granularity: 'MONTH',
        factor: 1
      },
      days: 30,
      disabled: false
    }, {
      id: 'three-month',
      query: {
        granularity: 'MONTH',
        factor: 3
      },
      days: 30,
      disabled: false
    }, {
      id: 'six-month',
      query: {
        granularity: 'MONTH',
        factor: 6
      },
      days: 30,
      disabled: false
    }, {
      id: 'year',
      query: {
        granularity: 'YEAR',
        factor: 1
      },
      days: 365,
      disabled: false
    }];

    this.get = function () {
      return intervals;
    };

    this.select = function (id) {
      var selectedInterval;
      intervals.each(function (interval) {
        if (interval.id === id) {
          selectedInterval = interval;
        }
      });
      return selectedInterval.query;
    };
  });
