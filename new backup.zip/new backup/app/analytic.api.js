'use strict';

function AnalyticApi($resource) {
  return $resource('api/analytic/request/:entityType/:typeID', {
    typeID: '@typeID'
  }, {
    list: {
      method: 'GET',
      isArray: false
    }
  });
}

angular.module('propel-analytic-ui')
  .factory('AnalyticApi', ['$resource', AnalyticApi]);
