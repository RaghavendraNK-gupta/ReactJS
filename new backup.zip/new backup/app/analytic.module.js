'use strict';

Date.prototype.addDays = function (days) {
  var d = new Date(this.valueOf());
  d.setDate(d.getDate() + days);
  return d;
};

angular.module('propel-analytic-ui', []);
