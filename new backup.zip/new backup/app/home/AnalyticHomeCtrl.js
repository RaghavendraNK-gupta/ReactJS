'use strict';

function AnalyticHomeCtrl($stateParams, $location, $scope, intervals) {
  var vm = this;

  function initializeParams(params) {
    var now = vm.now = new Date();
    var last30 = new Date(now.getTime() - (1000 * 60 * 60 * 24 * 30));
    params = params || {};
    params.interval = params.interval || 'week';
    params.from = params.from || last30.toISOString();
    params.to = params.to || now.toISOString();
    return params;
  }

  function updatePath(params) {
    $location.search(params).replace();
  }

  function checkDateRange() {
    if (vm.query.from > vm.query.to) {
      vm.query.from = vm.query.to;
    }
  }

  vm.query = initializeParams($stateParams);
  $location.search(vm.query).replace();

  vm.intervals = intervals.get();
  vm.isActive = function (interval) {
    return vm.query.interval === interval.id;
  };

  vm.setInterval = function (interval) {
    vm.query.interval = interval.id;
    updatePath(vm.query);
  };



  $scope.$watch('vm.query', function () {
    updatePath(vm.query);
    vm.disableIntervals();
    checkDateRange();
  }, true);

  vm.disableIntervals = function () {
    if (vm.query.to && vm.query.from) {
      var from = new Date(vm.query.from);
      var to = new Date(vm.query.to);

      if (to > from) {
        var diff = to.getTime() - from.getTime();
        var days = Math.round(diff / (1000 * 60 * 60 * 24));
        angular.forEach(vm.intervals, function (obj) {
          var intervalDays = obj.query.factor * obj.days;
          if (days < intervalDays) {
            obj.disabled = true;
            if (vm.query.interval === obj.id) {
              vm.query.interval = 'week';
            }
          } else {
            obj.disabled = false;
          }
        });
      }
    }
  };
}

angular.module('propel-analytic-ui')
  .controller('AnalyticHomeCtrl', ['$stateParams', '$location', '$scope', 'intervals', AnalyticHomeCtrl]);
