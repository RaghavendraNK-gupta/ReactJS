'use strict';

require('sugar');
// var services = require('../models/services.model');
var ApiError = require('@propel/msvc-util').error;
var mocking = require('../mocks/mockdata');
var granularity = require('../utils/granularity.transform');

var api = {
	list: 'requests/sunburst',
	get: 'requests/sunburst/{id}'
}
module.exports = function (provider, logger) {
	return {
		getServices: function (req, res, next) {
			logger.trace('getServices');
			if (req.query.mock) {
				mocking.setLogger(logger);
				var mock = mocking.create(req.query.granularity, [req.query.state],
					req.query.type, req.query.from, req.query.to, 'services', 3);
				res.setHeader('Content-Type', 'application/json');
				mock.factor = req.query.factor;
				res.json(granularity.transform(mock, req.query.factor, 'services'));
			} else {
				provider.request
					.get({
						url: provider.getUrlPath(api.list),
						qs: Object.reject(req.query, 'factor'),
						json: true,
						headers: {
							'X-Auth-Token': req.user.token.id
						}
					}, function (error, response, body) {
						if (error) {
							logger.error('Error encountered while rerieving graph data: ', req.query, error.stack);
							next(ApiError.wrap(error));
						} else if (response.statusCode >= 400) {
							logger.error('Error encountered while rerieving graph data: ', req.query, response.statusCode, body);
							next(ApiError.relay(response, body));
						} else {
							res.json(granularity.transform(body, req.query.factor, 'services'));
						}
					});
			}
		},
		getServicesItem: function (req, res, next) {

		}
	}
}