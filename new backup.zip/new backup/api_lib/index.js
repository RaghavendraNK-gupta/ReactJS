'use strict';

var assert = require('assert');
var express = require('express');
var cache = require('@propel/propel-cache');
var apiErrorHandler = require('@propel/msvc-util').error.handler;
var services = require('./controllers/services.controller');
var mChart = require('./controllers/mChart.controller');
var supports = require('./controllers/supports.controller');
var sunburst = require('./controllers/sunburst.controller');

var forwardFactory = require('@propel/msvc-util').forward;
var Provider = require('@propel/msvc-util').Provider;
var assert = require('assert');

module.exports = {
	auth: function (server) {
		var opts = this.config.getConfig('analytic');
		assert.ok(this.config, '`analytic.config` is not defined');

		var logger = server.logger;
		opts.logger = logger;

		cache = cache.cache(opts);

		var forward = forwardFactory(opts, logger);
		var analyticProvider = new Provider(opts);

		var router = express.Router();

		var servicesCtrl = services(analyticProvider, logger);
		var sunburstCtrl = sunburst(analyticProvider, logger);
		var supportsCtrl = supports(analyticProvider, logger);

		var mchartCtrl = mChart(analyticProvider, logger);

		router.use(apiErrorHandler());
		server.use('/api/analytic/request', router);

		router.use(server.auth('idm-auth-api'));
		router.route('/services')
			.all(cache.noCache())
			.get(servicesCtrl.getServices);
		router.route('/sunburst')
			.all(cache.noCache())
			.get(sunburstCtrl.getServices);

		router.route('/supports')
			.all(cache.noCache())
			.get(supportsCtrl.getSupports);

		router.route('/supports')
		router.route('/multiChart')
			.all(cache.noCache())
			.get(mchartCtrl.getServices);

		router.use(apiErrorHandler());
		server.use('/api/analytic/request', router);

	}
};