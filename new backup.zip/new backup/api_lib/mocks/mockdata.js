'use strict';

require('sugar');
// Using a seeded random so that the numbers output are the same every time depending on the seed used.
//  This is done for predictablity in testing.  This also allows for unbounded large datasets.
var seedrandom = require('seedrandom');

var ONE_DAY = 24 * 60 * 60 * 1000;
var ONE_WEEK = ONE_DAY * 7;
var LOGGER = console;

var services = ['Web Site Hosting', 'Virtual Machine Provisioning', 'Onboarding '];
var supports = ['Report Printer Problem', 'Report Intrusion', 'Report Broken Chair'];

var header = {
	'granularity': '',
	'states': [],
	'serviceCount': 3,
	'currency': 'EUR',
	'from': 0,
	'to': 10
};


/**
 * Smooth out the random data so that it looks good on a graph
 */
function smoothRandom(factor, start, rng) {
	var last = (start !== undefined) ? start : rng();
	var halfEnvelope = (1 / factor) / 2;
	return function () {
		// clamp output range to [0,1] as Math.random()
		var max = Math.min(1, last + halfEnvelope);
		var min = Math.max(0, last - halfEnvelope);
		// return a number within halfRange of the last returned value
		last = rng() * (max - min) + min;
		return last;
	};
}

//Heavily borrowed from stack overflow.
function divFromGranularity(g, from, to) {
	var dateFrom = new Date(from);
	var dateTo = new Date(to);
	var diff;
	switch (g) {
	case 'YEAR':
		var ageDifMs = dateTo - dateFrom;
		var ageDate = new Date(ageDifMs); // miliseconds from epoch
		diff = Math.abs(ageDate.getUTCFullYear() - 1970);
		break;
	case 'WEEK':
		// Convert both dates to milliseconds
		var date1_ms = dateTo.getTime();
		var date2_ms = dateFrom.getTime();
		// Calculate the difference in milliseconds
		var difference_ms = Math.abs(date1_ms - date2_ms);
		// Convert back to weeks and return hole weeks
		diff = Math.floor(difference_ms / ONE_WEEK);
		break;
	case 'MONTH':
		var months;
		months = (dateTo.getFullYear() - dateFrom.getFullYear()) * 12;
		months -= dateFrom.getMonth() + 1;
		months += dateTo.getMonth();
		diff = months <= 0 ? 0 : months;
		break;
	case 'DAY':
		diff = Math.round(Math.abs((dateFrom.getTime() - dateTo.getTime()) / ONE_DAY));
		break;
	default:
		diff = Math.round(Math.abs((dateFrom.getTime() - dateTo.getTime()) / ONE_DAY));
	}
	return diff || 1;
}


function getData(baseSeed, numValues, maxValue, type, states, i, dataType) {
	var arr = [];
	var val;
	var prev;
	var rng;

	if (dataType === 'services') {
		rng = seedrandom(baseSeed + services[i]);

	} else if (dataType === 'supports') {
		rng = seedrandom(baseSeed + supports[i]);
	}


	for (var j = 0, k = numValues + 1; j < k; j++) {
		prev = smoothRandom(20, prev, rng)();
		val = Math.floor(prev * maxValue);
		if (type === 'COST') {
			// get a decimal for price and make sure its truncated to 2 spots.  Dont care about accuracy of float.
			val = Math.floor(val * 0.01 * 100) / 100;
		}
		if (type === 'ALL') {
			val = {
				cost: Math.floor(val * 0.01 * 100) / 100,
				count: Math.floor(val / 10000)
			}
		}
		if (states[0] === 'ALL') {

			val = {
				open: Math.floor(val * 0.01 * 100) / 100,
				fulfilled: Math.floor(val * 100) / 100
			}
		}
		arr.push(val);
	}
	return arr;
}


/**
 * Create Mockdata
 * @param  {string}        granularity      MONTH|WEEK|YEAR  Also have coded for DAY
 * @param  {Array<string>} states           OPEN|FULFLLED (But can be arbitrary) The State that either a support or service should be in
 * @param  {string}        type             COST|COUNT
 * @param  {string}        from             ISO-8601 standard date representing the first date in the time interval --- inclusive
 * @param  {string}        to               ISO-8601 standard date representing the last date in the time interval --- inclusive
 * @param  {string}        dataType         SUPPORT|SERVICE
 * @param  {number}        numDataType      The number of supports or services to return
 * @return {Object}  The format that is returned by the standard java api.
 */
function createMockData(granularity, states, type, from, to, dataType, numDataType) {
	LOGGER.info('**** Using Mock Data');

	var maxValue = type === 'COUNT' ? 100 : 1000000;

	var mockData = Object.extended(header);
	mockData.granularity = granularity;
	mockData.states = states;
	mockData.type = type;
	mockData.from = from;
	mockData.to = to;
	mockData[dataType] = [];

	var baseSeed = states.join();

	var data = mockData[dataType];
	var numValues = divFromGranularity(granularity, from, to);
	for (var i = 0, n = numDataType; i < n; i++) {
		var obj = {};
		if (dataType === 'services') {
			obj.name = services[i];
		} else if (dataType === 'supports') {
			obj.name = supports[i];
		}

		obj.values = getData(baseSeed, numValues, maxValue, type, states, i, dataType);
		data.push(obj);
	}
	return mockData;
}

function setLogger(logger) {
	LOGGER = logger;
}

module.exports = {
	create: createMockData,
	setLogger: setLogger
};