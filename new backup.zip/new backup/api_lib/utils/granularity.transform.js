'use strict';

require('sugar');

function transform(body, factor, entityType) {
  //In case factor was passed in as string or undefined...
  factor = factor * 1;
  if (isNaN(factor) || factor === 1) {
    return body;
  }

  function transformNumberArray(body, factor, entityType) {
    body[entityType].each(function (entity) {

      var factorTransform = [];
      var transformValue = 0;

      //Adds extra zeros to end of array to make length%factor = 0 to simplify transform logic.
      //e.g [24] when factor is 3 becomes: [24, 0, 0]
      if (entity.values.length % factor !== 0) {
        for (var i = factor - entity.values.length % factor; i > 0; i--) {
          entity.values.push(0);
        }
      }

      //For each entity...
      entity.values.each(function (value, index) {
        transformValue += value;
        //use factor-1 since array index starts at zero...
        //after we have summed up factor*1 values in the array push it to factorTransform array
        if (index % factor === factor - 1) {
          factorTransform.push(transformValue);
          transformValue = 0;
        }
      });
      //Overwrite the origional values array with the factor transformed array.
      entity.values = factorTransform;
    });
  }

  function transformObjArray(body, factor, entityType) {

    function incrementObject(obj, incrementObj, keys) {
      keys.each(function (key) {
        obj[key] += incrementObj[key];
      })
    }

    function createZeroObject(keys) {
      var zeroObject = {};
      keys.each(function (key) {
        zeroObject[key] = 0;
      })

      return zeroObject;
    }

    body[entityType].each(function (entity) {

      var keys = Object.keys(entity.values[0]);
      var factorTransform = [];
      var transformValue = createZeroObject(keys);


      //Adds extra zeros to end of array to make length%factor = 0 to simplify transform logic.
      //e.g [24] when factor is 3 becomes: [24, 0, 0]
      if (entity.values.length % factor !== 0) {
        for (var i = factor - entity.values.length % factor; i > 0; i--) {
          entity.values.push(createZeroObject(keys));
        }
      }

      //For each entity...
      entity.values.each(function (value, index) {

        incrementObject(transformValue, value, keys);

        //use factor-1 since array index starts at zero...
        //after we have summed up factor*1 values in the array push it to factorTransform array
        if (index % factor === factor - 1) {
          factorTransform.push(transformValue);
          transformValue = createZeroObject(keys);
        }
      });
      //Overwrite the origional values array with the factor transformed array.
      entity.values = factorTransform;
    });
  }

  if (typeof body[entityType][0].values[0] === 'object') {
    transformObjArray(body, factor, entityType);
  } else {
    transformNumberArray(body, factor, entityType);
  }

  return body;
}

module.exports = {
  transform: transform
};
